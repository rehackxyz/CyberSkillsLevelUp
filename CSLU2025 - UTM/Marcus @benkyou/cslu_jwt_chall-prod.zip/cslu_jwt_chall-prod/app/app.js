const bcrypt = require('bcrypt');
const express = require('express');
const path = require('node:path');
const db = require('./db');
const cookieParser = require('cookie-parser');
const { generateToken, verifyToken } =  require('./middleware/token');

const port = 3000;
const saltRounds = 10;

const app = module.exports = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use('/static', express.static('public'))
app.use(express.json());
app.use(cookieParser());

function authenticate(username, password, fn) {
    if (!module.parent) console.log("authenticating %s:%s", username, password);
    db.query('SELECT * FROM users WHERE username = ? LIMIT 1', [username], (err, rows) => {
        if (err) return fn(err);

        if (rows.length === 0) {
            return fn(null, null);
        }

        user = rows[0];
        bcrypt.compare(password, user.password, (err, match) => {
            if (err) return fn(err);
            if (match) {
                return fn(null, user);
            }
            return fn(null, null);
        })
    });
}

app.get('/', (req, res) => {
    res.redirect('login');
});

app.get('/meow', verifyToken, (req, res) => {
    res.render('index');
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/api/login', (req, res, next) => {
    if (!req.body) return res.sendStatus(400);
    authenticate(req.body.username, req.body.password, (err, user) => {
        if (err) return next(err);
        if (!user) {
            return res.status(401).json({error: "Incorrect username or password"});
        }
        const token = generateToken({ username: user.username, role: user.role });
        res.cookie('token', token, {
            httpOnly: true,
            maxAge: 3600000
        });
        return res.status(200).json({ message: "Login successful" });
    });
});

app.get('/register', (req, res) => {
    res.render('register');
});

app.post('/api/register', (req, res) => {
    var { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: "Missing required fields" });
    }

    // Check if the user already exists
    db.query('SELECT * FROM users where username = ? LIMIT 1', [username], (err, rows) => {
        if (err) {
            return res.status(500).json({ error: "Database error" });
        }

        if (rows.length > 0) {
            return res.status(409).json({ error: "User already exists" });
        }

        // Create the user
        bcrypt.hash(password, saltRounds, (err, hash) => {
            if (err) {
                return res.status(500).json({ error: "Error creating user" });
            }

            db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hash], (err, result) => {
                if (err) {
                    return res.status(500).json({ error: "Error creating user" });
                }
                return res.status(201).json({ message: "User created successfully" });
            });
        });
    });
});

app.get('/logout', (req, res) => {
    res.clearCookie('token', {
        httpOnly: true,
        secure: true
    });
    res.redirect('/login');
});

app.get('/api/flag', verifyToken, (req, res) => {
    if (req.owner) {
        return res.status(200).json({ msg: process.env.FLAG });
    }
    return res.status(403).json({ msg: 'You are not the owner! 😠😠😠' });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});