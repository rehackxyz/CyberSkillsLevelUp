const jwt = require('jsonwebtoken');

const SECRET_KEY = 'insert_your_random_key_here';

function generateToken(payload) {
    return jwt.sign(payload, SECRET_KEY, {'expiresIn': '1hr'});
}

function verifyToken(req, res, next) {
    const token = req.cookies.token;
    // const token = req.headers['authorization']?.split(' ')[1];

    if (!token) {
        return res.status(400).json({error: 'Invalid token provided'});
    }

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) {
            return res.status(400).json({error: 'Invalid token signature'});
        }
        req.user = user;
        if (user && user.role === 'owner') {
            req.owner = true;
        } else {
            req.owner = false;
        }
        next();
    });
}


module.exports = {
    generateToken,
    verifyToken
}