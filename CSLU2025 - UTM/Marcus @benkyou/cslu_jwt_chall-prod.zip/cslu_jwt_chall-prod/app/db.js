// db.js
const mysql = require('mysql')

const connection = mysql.createConnection({
  host: 'db',
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: 'cslu_db'
})

connection.connect()

module.exports = connection
