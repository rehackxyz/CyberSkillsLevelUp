CREATE DATABASE IF NOT EXISTS cslu_db;

USE cslu_db;

CREATE TABLE IF NOT EXISTS student (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS employer (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    is_activated BOOL,
    recovery_code VARCHAR(16)
);

CREATE TABLE IF NOT EXISTS job (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description varchar(1024),
    employer_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employer_id) REFERENCES employer(id)
);

CREATE TABLE IF NOT EXISTS application (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    job_id INT,
    is_approved BOOL,
    FOREIGN KEY (student_id) REFERENCES student(id),
    FOREIGN KEY (job_id) REFERENCES job(id)
);

CREATE TABLE IF NOT EXISTS employer_otp (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employer_id INT NOT NULL,
    otp_value VARCHAR(32) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    FOREIGN KEY (employer_id) REFERENCES employer(id),
    INDEX idx_otp (otp_value)
);

INSERT INTO employer (name, email, password, is_activated) VALUES
('ZKSecure Labs', 'benkyou@cslu.com', '$2b$10$GT882TYqajIXevYoFuzZxOUWl7nIJ7S4DgaJENQDjicprGe8E7cZi', TRUE),
('MeowCore Sdn Bhd', 'meow@meowcore.com', '$2b$10$WyoGw.fmFp.SagAdfLJ9kO/r7WebkZ7s1WvT/kB.KK7Hv12sCyM6W', TRUE),
('ByteConnect Inc.', 'hr@byteconnect.com', '$2b$10$WyoGw.fmFp.SagAdfLJ9kO/r7WebkZ7s1WvT/kB.KK7Hv12sCyM6W', TRUE);

INSERT INTO job (title, description, employer_id) VALUES 
(
    'Penetration Tester Intern',
    "We're looking for a penetration tester intern who can prove their skills the real way. Just hack us and you're in!
    Compensation: RM 5000 per month",
    (SELECT id FROM employer WHERE name = 'ZKSecure Labs')
),
(
    'Software Engineer Intern',
    "MeowCore Sdn. Bhd. is seeking a Software Engineering Intern to join our team in building innovative, scalable web applications. You'll work alongside experienced developers on real-world projects, contributing to both frontend and backend development. This is a full-time internship with a monthly compensation of RM 1200.",
    (SELECT id FROM employer WHERE name = 'MeowCore Sdn Bhd')
),
(
    'AI Engineer Intern',
    "ByteConnect Inc. is looking for an AI Engineer Intern to assist in developing and optimizing machine learning models for real-world applications. You’ll work with our AI team on data preprocessing, model training, and performance evaluation. This is a full-time internship with a monthly compensation of RM 1500.",
    (SELECT id FROM employer WHERE name = 'ByteConnect Inc.')
);