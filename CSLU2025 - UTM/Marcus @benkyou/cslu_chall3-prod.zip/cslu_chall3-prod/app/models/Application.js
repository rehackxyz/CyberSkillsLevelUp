const pool = require('../config/db');

class Application {
    static async create(student_id, job_id) {
        try {
            const [result] = await pool.query(
                'INSERT INTO application (student_id, job_id, is_approved) VALUES (?, ?, FALSE)',
                [student_id, job_id]
            );
            return result.insertId;
        } catch (error) {
            throw error;
        }
    }

    static async findByEmployerId(employer_id) {
        try {
            const [rows] = await pool.query(`
                SELECT a.*, s.name as student_name, s.email as student_email,
                       j.title as job_title, j.description as job_description
                FROM application a
                JOIN job j ON a.job_id = j.id
                JOIN student s ON a.student_id = s.id
                WHERE j.employer_id = ?`, [employer_id]);
            return rows;
        } catch (error) {
            throw error;
        }
    }

    static async findByStudentId(student_id) {
        try {
            const [rows] = await pool.query(`
                SELECT a.*, j.title as job_title, j.description as job_description,
                       e.name as employer_name
                FROM application a
                JOIN job j ON a.job_id = j.id
                JOIN employer e ON j.employer_id = e.id
                WHERE a.student_id = ?`, [student_id]);
            return rows;
        } catch (error) {
            throw error;
        }
    }

    static async findByJobId(job_id, employer_id) {
        try {
            const [rows] = await pool.query(`
                SELECT a.*, s.name as student_name, s.email as student_email
                FROM application a
                JOIN student s ON a.student_id = s.id
                JOIN job j ON a.job_id = j.id
                WHERE a.job_id = ? AND j.employer_id = ?`, 
                [job_id, employer_id]);
            return rows;
        } catch (error) {
            throw error;
        }
    }

    static async updateApprovalStatus(application_id, employer_id, is_approved) {
        try {
            const [result] = await pool.query(`
                UPDATE application a
                JOIN job j ON a.job_id = j.id
                SET a.is_approved = ?
                WHERE a.id = ? AND j.employer_id = ?`,
                [is_approved, application_id, employer_id]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    static async hasApplied(student_id, job_id) {
        try {
            const [rows] = await pool.query(
                'SELECT COUNT(*) as count FROM application WHERE student_id = ? AND job_id = ?',
                [student_id, job_id]
            );
            return rows[0].count > 0;
        } catch (error) {
            throw error;
        }
    }

    static async delete(application_id, employer_id) {
        try {
            const [result] = await pool.query(`
                DELETE a FROM application a
                JOIN job j ON a.job_id = j.id
                WHERE a.id = ? AND j.employer_id = ?`, 
                [application_id, employer_id]);
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = Application;