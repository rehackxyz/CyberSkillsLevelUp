const pool = require('../config/db.js');

class Student {
    static async create(name, email, password) {
        const [result] = await pool.query(
            'INSERT INTO student (name, email, password) VALUES (?, ?, ?)',
            [name, email, password]
        );
        return result.insertId;
    }

    static async findByEmail(email) {
        const [rows] = await pool.query('SELECT * FROM student WHERE email = ?', [email]);
        return rows[0];
    }

    static async findById(id) {
        const [rows] = await pool.query('SELECT * FROM student WHERE id = ?', [id]);
        return rows[0];
    }

    static async update(id, data) {
        const [result] = await pool.query(
            'UPDATE student SET ? WHERE id = ?',
            [data, id]
        );
        return result.affectedRows > 0;
    }

    static async delete(id) {
        const [result] = await pool.query('DELETE FROM student WHERE id = ?', [id]);
        return result.affectedRows > 0;
    }
}

module.exports = Student;