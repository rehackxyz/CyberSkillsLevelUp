const pool = require('../config/db');

class Job {
    static async create(title, description, employer_id) {
        try {
            const [result] = await pool.query(
                'INSERT INTO job (title, description, employer_id) VALUES (?, ?, ?)',
                [title, description, employer_id]
            );
            return result.insertId;
        } catch (error) {
            throw error;
        }
    }

    static async findAll() {
        try {
            const [rows] = await pool.query(`
                SELECT j.*, e.name as employer_name, e.email as employer_email 
                FROM job j
                LEFT JOIN employer e ON j.employer_id = e.id`);
            return rows || null;
        } catch (error) {
            throw error;
        }
    }
    
    static async findById(id) {
        try {
            const [rows] = await pool.query(`
                SELECT j.*, e.name as employer_name, e.email as employer_email 
                FROM job j
                LEFT JOIN employer e ON j.employer_id = e.id 
                WHERE j.id = ? 
                LIMIT 1`, [id]);
            return rows[0] || null;
        } catch (error) {
            throw error;
        }
    }

    static async findByEmployerId(employer_id) {
        try {
            const [rows] = await pool.query(`
                SELECT j.*, e.name as employer_name, e.email as employer_email 
                FROM job j
                LEFT JOIN employer e ON j.employer_id = e.id 
                WHERE j.employer_id = ?`, [employer_id]);
            return rows;
        } catch (error) {
            throw error;
        }
    }

    static async update(id, data) {
        try {
            const setClause = Object.keys(data)
                .map(key => `${key} = ?`)
                .join(', ');

            const values = Object.values(data);
            values.push(id);

            const [result] = await pool.query(
                `UPDATE job SET ${setClause} WHERE id = ?`,
                values
            );

            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    static async delete(id) {
        try {
            const [result] = await pool.query('DELETE FROM job WHERE id = ?', [id]);
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = Job;