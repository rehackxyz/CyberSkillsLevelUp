const pool = require('../config/db');

class Employer {
    static async create(name, email, password) {
        try {
            const recoveryCode = generateRecoveryCode(16);

            const [result] = await pool.query(
                'INSERT INTO employer (name, email, password, recovery_code, is_activated) VALUES (?, ?, ?, ?, FALSE)',
                [name, email, password, recoveryCode]
            );
            return result.insertId;
        } catch (error) {
            throw error;
        }
    }

    static async findById(id) {
        try {
            const [rows] = await pool.query('SELECT * FROM employer WHERE id = ? LIMIT 1', [id]);
            return rows[0] || null;
        }
        catch (error) {
            throw error;
        }
    }

    static async findByEmail(email) {
        try {
            const [rows] = await pool.query('SELECT * FROM employer WHERE email = ? LIMIT 1', [email]);
            return rows[0] || null;
        }
        catch (error) {
            throw error;
        }
    }

    static async update(id, data) {
        try {
            // Build SET clause manually
            const setClause = Object.keys(data)
                .map(key => `${key} = ?`)
                .join(', ');

            const values = Object.values(data);
            values.push(id);

            const [result] = await pool.query(
                `UPDATE employer SET ${setClause} WHERE id = ?`,
                values
            );

            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }

    static async delete(id) {
        try {
            const [result] = await pool.query('DELETE FROM employer WHERE id = ?', [id]);
            return result.affectedRows > 0;
        }
        catch (error) {
            throw error;
        }
    }

    static async reset(email, recoveryCode) {
        try {
            const [result] = await pool.query(
                'UPDATE employer SET is_activated = 1 WHERE email = ? AND recovery_code = ?',
                [email, recoveryCode]
            );
            return result.affectedRows > 0;
        } catch (error) {
            throw error;
        }
    }
    
    static async generateOTP(employerId) {
        try {
            // Generate random OTP
            const otp = Math.random().toString(36).substring(2, 15);

            // Set expiration to 24 hours from now
            const date = new Date();
            date.setMinutes(date.getMinutes() + 5);
            const expiresAt = date.toISOString().slice(0, 19).replace('T', ' ');

            // Store OTP in database
            await pool.query(
                'INSERT INTO employer_otp (employer_id, otp_value, expires_at) VALUES (?, ?, ?)',
                [employerId, otp, expiresAt]
            );

            return otp;
        } catch (error) {
            throw error;
        }
    }

    static async verifyOTP(otp, email) {
        try {
            const [rows] = await pool.query(`
                SELECT e.* FROM employer e
                INNER JOIN employer_otp eo
                WHERE eo.otp_value = ?
                AND eo.expires_at > NOW()
                AND e.email = ?
                LIMIT 1`,
            [otp, email]);

            if (rows[0]) {
                await pool.query('DELETE FROM employer_otp WHERE otp_value = ?', [otp]);
            }

            return rows[0] || null;
        } catch (error) {
            throw error;
        }
    }
}

function generateRecoveryCode(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

module.exports = Employer;