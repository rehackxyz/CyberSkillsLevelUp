var express = require('express');
const { requireEmployer } = require('../middleware/authMiddleware');
const { getJobs, getJobById, createJob, updateJob, deleteJob } = require('../controllers/jobController');
var router = express.Router();

// Public routes
router.get('/', getJobs);
router.get('/:id', getJobById);

// Protected routes
// For employers to update their jobs
router.post('/', requireEmployer, createJob);
router.put('/:id', requireEmployer, updateJob);
router.delete('/:id', requireEmployer, deleteJob);

module.exports = router;