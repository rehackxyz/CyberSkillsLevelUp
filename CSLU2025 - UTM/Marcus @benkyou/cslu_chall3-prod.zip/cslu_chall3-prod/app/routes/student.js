var express = require('express');
const { registerStudent, getStudentById, updateStudent, deleteStudent, getStudents, getStudentSelf } = require('../controllers/studentController');
const { loginStudent } = require('../controllers/authController');
const { requireStudent } = require('../middleware/authMiddleware');
var router = express.Router();

// Public routes
router.get('/', getStudents);
router.post('/login', loginStudent);
router.post('/register', registerStudent);

// Protected routes
router.get('/me', requireStudent, getStudentSelf);
router.get('/:id', requireStudent, getStudentById);
router.put('/:id', requireStudent, updateStudent);
router.delete('/:id', requireStudent, deleteStudent);

module.exports = router;