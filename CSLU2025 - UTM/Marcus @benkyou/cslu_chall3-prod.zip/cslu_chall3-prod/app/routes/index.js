const express = require('express');
const router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
  res.redirect('/jobs');
});

// Login page
router.get('/login', (req, res) => {
  res.render('login', {
    title: 'Login - IMS'
  });
});

// Register page
router.get('/register', (req, res) => {
  const userType = req.query.type || 'student';
  res.render('register', {
    title: 'Register - IMS',
    userType: userType
  });
});

// Job Board page
router.get('/jobs', async (req, res) => {
  res.render('jobs', {
    title: 'Internship Opportunities - IMS'
  });
});

// Employer dashboard
router.get('/employer', async (req, res) => {
  res.render('employerDashboard', {
    title: 'Employer Dashboard - IMS'
  });
});

// OTP Login
router.get('/login/otp/:encodedEmail/:otp', (req, res) => {
  res.render('otpLogin', {
    title: 'OTP Login - IMS',
    encodedEmail: req.params.encodedEmail,
    otp: req.params.otp
  });
});

// Profile page
router.get('/profile', (req, res) => {
  res.render('profile', { title: 'My Profile - IMS' });
});

// Application Status page
router.get('/applicationStatus', (req, res) => {
  res.render('applicationStatus', { title: 'Application Status - IMS' });
});

module.exports = router;
