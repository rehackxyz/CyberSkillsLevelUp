var express = require('express');
const { registerEmployer, updateEmployer, getEmployerById, deleteEmployer, getEmployers, getEmployerSelf } = require('../controllers/employerController');
const { loginEmployer, generateEmployerOTP, loginWithOTP, resetEmployerAccount } = require('../controllers/authController');
const { requireEmployer } = require('../middleware/authMiddleware');
var router = express.Router();


router.get('/me', requireEmployer, getEmployerSelf);
// Public routes
router.get('/', getEmployers);
router.get('/:id', getEmployerById);
router.post('/login', loginEmployer);
router.post('/register', registerEmployer);
router.post('/generate-otp', requireEmployer, generateEmployerOTP);
router.get('/login/otp/:encodedEmail/:otp', loginWithOTP);
router.post('/reset-account', resetEmployerAccount);

// Protected routes
router.put('/:id', requireEmployer, updateEmployer);
router.delete('/:id', requireEmployer, deleteEmployer);

module.exports = router;