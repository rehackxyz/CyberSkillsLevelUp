const express = require('express');
const router = express.Router();
const { requireStudent, requireEmployer } = require('../middleware/authMiddleware');
const { createApplication, getStudentApplications, getEmployerApplications, getJobApplications, updateApplicationStatus, deleteApplication } = require('../controllers/applicationController');

// Student routes
router.get('/my-applications', requireStudent, getStudentApplications);
router.post('/apply', requireStudent, createApplication);

// Employer routes
router.get('/employer/applications', requireEmployer, getEmployerApplications);
router.get('/employer/:job_id/applications', requireEmployer, getJobApplications);
router.put('/employer/application/:application_id', requireEmployer, updateApplicationStatus);
router.delete('/employer/application/:application_id', requireEmployer, deleteApplication);

module.exports = router;