const jwt = require('jsonwebtoken');
const asyncHandler = require('express-async-handler');

// We use a different key on the challenge server :D
const SECRET_KEY = process.env.SECRET_KEY || 'your_secret_key';

function generateToken(payload) {
    return jwt.sign(payload, SECRET_KEY, { algorithm: 'HS256', issuer: 'cslu', expiresIn: '1hr' });
}

const verifyToken = asyncHandler(async (req, res, next) => {
    let token;

    // Parse token from header
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
        return res.status(401).json({ msg: 'Invalid token provided' });
    }

    // Verify the token
    try {
        const payload = jwt.verify(token, SECRET_KEY, { algorithms: 'HS256' });

        req.user = {
            id: payload.id,
            email: payload.email,
            role: payload.role
        };

        next();
    } catch (error) {
        return res.status(401).json({ msg: 'Invalid token provided' });
    }
});

module.exports = {
    generateToken,
    verifyToken
};