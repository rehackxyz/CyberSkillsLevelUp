const asyncHandler = require('express-async-handler');
const { verifyToken } = require('../utils/token');
const Student = require('../models/Student');
const Employer = require('../models/Employer');

const requireStudent = asyncHandler(async (req, res, next) => {
    await verifyToken(req, res, async () => {
        try {
            if (req.user.role !== 'student') {
                return res.status(403).json({ msg: "Hey you're not a student 🧑‍🎓" });
            }

            const student = await Student.findById(req.user.id);
            if (!student) {
                return res.status(404).json({ msg: "Nice try 👀 but that student doesn't exists" });
            }
            next();
        } catch (error) {
            return res.status(401).json({ msg: `Invalid token provided ${error.message}` });
        }
    });
});

const requireEmployer = asyncHandler(async (req, res, next) => {
    await verifyToken(req, res, async () => {
        try {
            if (req.user.role !== 'employer') {
                return res.status(403).json({ msg: "Hey you're not an employer 🧑‍💼" });
            }

            const employer = await Employer.findById(req.user.id);
            if (!employer) {
                return res.status(404).json({ msg: "Nice try 👀 but that employer doesn't exists" });
            }
            if (!employer.is_activated) {
                return res.status(403).json({ msg: 'Employer account is not activated. Please contact the administrator.' });
            }
            
            next();
        } catch (error) {
            return res.status(401).json({ msg: `Invalid token provided ${error.message}` });
        }
    });
});

module.exports = {
    requireStudent,
    requireEmployer
};