const asyncHandler = require('express-async-handler');
const Application = require('../models/Application');
const Job = require('../models/Job');

// @desc    Create a new job application
// @route   POST /api/applications/apply
// @access  Private/Student
const createApplication = asyncHandler(async (req, res) => {
    const student_id = req.user.id;
    const { job_id } = req.body
    
    const hasApplied = await Application.hasApplied(student_id, job_id);
    if (hasApplied) {
        res.status(400);
        throw new Error('Already applied for this job');
    }

    const applicationId = await Application.create(student_id, job_id);
    if (applicationId) {
        res.status(201).json({
            message: 'Application submitted successfully',
            application_id: applicationId
        });
    } else {
        res.status(400);
        throw new Error('Invalid application data');
    }
});

// @desc    Get all applications for an employer
// @route   GET /api/applications/employer/
// @access  Private/Employer
const getEmployerApplications = asyncHandler(async (req, res) => {
    const employer_id = req.user.id;
    const applications = await Application.findByEmployerId(employer_id);
    res.status(200).json(applications);
});

// @desc    Get all applications for a student
// @route   GET /api/applications/my-applications
// @access  Private/Student
const getStudentApplications = asyncHandler(async (req, res) => {
    try {
        const student_id = req.user.id;
        const applications = await Application.findByStudentId(student_id);

        // Will you be their new intern?
        const isFlag = applications.find(app =>
            app.job_id === 1 &&
            app.is_approved === 1
        );

        if (isFlag) {
            return res.status(200).json({
                applications: applications,
                flag: process.env.FLAG
            });
        }
        
        return res.status(200).json(applications);
    } catch (error) {
        return res.status(500).json({ message: 'Server error' });
    }
});

// @desc    Get all applications for a specific job
// @route   GET /api/applications/employer/:job_id/applications
// @access  Private/Employer
const getJobApplications = asyncHandler(async (req, res) => {
    const { job_id } = req.params;
    const employer_id = req.user.id;

    const job = await Job.findById(job_id);
    if (!job || job.employer_id !== employer_id) {
        res.status(403);
        throw new Error('Unauthorized access');
    }

    const applications = await Application.findByJobId(job_id, employer_id);
    res.status(200).json(applications);
});

// @desc    Update application approval status
// @route   PUT /api/applications/employer/application/:application_id
// @access  Private/Employer
const updateApplicationStatus = asyncHandler(async (req, res) => {
    const { application_id } = req.params;
    const { is_approved } = req.body;
    const employer_id = req.user.id;

    const updated = await Application.updateApprovalStatus(application_id, employer_id, is_approved);
    if (!updated) {
        res.status(404);
        throw new Error('Application not found or unauthorized');
    }

    res.status(200).json({ message: 'Application status updated successfully' });
});

// @desc    Delete an application
// @route   DELETE /api/applications/employer/application/:application_id
// @access  Private/Employer
const deleteApplication = asyncHandler(async (req, res) => {
    const { application_id } = req.params;
    const employer_id = req.user.id;

    const deleted = await Application.delete(application_id, employer_id);
    if (!deleted) {
        res.status(404);
        throw new Error('Application not found or unauthorized');
    }

    res.status(200).json({ message: 'Application deleted successfully' });
});

module.exports = {
    createApplication,
    getEmployerApplications,
    getStudentApplications,
    getJobApplications,
    updateApplicationStatus,
    deleteApplication
};