const asyncHandler = require('express-async-handler');
const Student = require('../models/Student.js');
const bcrypt = require('bcryptjs');

// @desc    Register a new student
// @route   POST /api/students
// @access  Public
const registerStudent = asyncHandler(async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        res.status(400);
        throw new Error('Missing required fields');
    }

    const studentExists = await Student.findByEmail(email);
    if (studentExists) {
        res.status(400);
        throw new Error('Student already exists');
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const studentId = await Student.create(name, email, hashedPassword);
    const student = await Student.findById(studentId);

    if (student) {
        res.status(201).json({
            id: student.id,
            name: student.name,
            email: student.email
        });
    } else {
        res.status(400);
        throw new Error('Invalid student data');
    }
});

// :)
const getStudents = asyncHandler(async (req, res) => {
    res.status(200).json({
        msg: 'HAH YOU THOUGHT?'
    });
});

// @desc    Get own student profile
// @route   GET /api/student/me
// @access  Private
const getStudentSelf = asyncHandler(async (req, res) => {
    const student = await Student.findById(req.user.id);
    if (!student) {
        res.status(404).json({ msg: "You need to be registered????"})
    }
    res.status(200).json({
        id: student.id,
        name: student.name,
        email: student.email
    });
});


// @desc    Get student by ID
// @route   GET /api/students/:id
// @access  Private
const getStudentById = asyncHandler(async (req, res) => {
    const student = await Student.findById(req.params.id);
    if (student) {
        res.status(200).json({
            id: student.id,
            name: student.name,
            email: student.email
        });
    } else {
        res.status(404);
        throw new Error('Student not found');
    }
});

// @desc    Update student
// @route   PUT /api/students/:id
// @access  Private
const updateStudent = asyncHandler(async (req, res) => {
    const student = await Student.findById(req.params.id);

    if (!student) {
        res.status(404);
        throw new Error('Student not found');
    }

    const { password, ...updateData } = req.body;
    
    if (password) {
        const salt = await bcrypt.genSalt(10);
        updateData.password = await bcrypt.hash(password, salt);
    }

    const updated = await Student.update(req.params.id, updateData);
    if (updated) {
        const updatedStudent = await Student.findById(req.params.id);
        res.status(200).json({
            id: updatedStudent.id,
            name: updatedStudent.name,
            email: updatedStudent.email
        });
    } else {
        res.status(400);
        throw new Error('Failed to update student');
    }
});

// @desc    Delete student
// @route   DELETE /api/students/:id
// @access  Private/Admin
const deleteStudent = asyncHandler(async (req, res) => {
    const deleted = await Student.delete(req.params.id);
    if (deleted) {
        res.status(200).json({ message: 'Student removed' });
    } else {
        res.status(404);
        throw new Error('Student not found');
    }
});

module.exports = {
    registerStudent,
    getStudents,
    getStudentSelf,
    getStudentById,
    updateStudent,
    deleteStudent
};