const asyncHandler = require('express-async-handler');
const Employer = require('../models/Employer');
const bcrypt = require('bcryptjs');
const { validationResult } = require('express-validator');

// @desc    Register a new employer
// @route   POST /api/employer
// @access  Public
const registerEmployer = asyncHandler(async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { name, email, password } = req.body;

    // check if Employer already exists
    const employerExists = await Employer.findByEmail(email);
    if (employerExists) {
        return res.status(409).json({ msg: 'Employer is already registered' });
    }

    const hash = await bcrypt.hash(password, 10);

    // create the Employer
    const employerId = await Employer.create(name, email, hash);
    const employer = await Employer.findById(employerId);

    res.status(201).json({
        msg: 'Employer registered successfully',
        employer: {
            id: employer.id,
            name: employer.name,
            email: employer.email,
            recovery_code: employer.recovery_code
        }
    });
});

// :)
const getEmployers = asyncHandler(async (req, res) => {
    res.status(200).json({ msg: 'Nice try lol' });
});

const getEmployerById = asyncHandler(async (req, res) => {
    const employer = await Employer.findById(req.params.id);
    if (!employer) {
        res.status(404).json({ msg: 'Employer not found' });
    }
    res.status(200).json({
        id: employer.id,
        name: employer.name,
        email: employer.email
    });
});

// @desc    Get own employer profile
// @route   GET /api/employer/me
// @access  Private
const getEmployerSelf = asyncHandler(async (req, res) => {
    const employer = await Employer.findById(req.user.id);
    if (!employer) {
        res.status(404).json({ msg: "You need to be registered????"})
    }
    res.status(200).json({
        id: employer.id,
        name: employer.name,
        email: employer.email
    });
});

// @desc    Update employer
// @route   PUT /api/employer/:id
// @access  Private
const updateEmployer = asyncHandler(async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const id = req.params.id;
    const { name, email, password } = req.body;

    const employerExists = await Employer.findById(id);
    if (!employerExists) {
        return res.status(404).json({ msg: 'Employer not found' });
    }

    // Prepare data to update
    const updateData = {};
    if (name) updateData.name = name;
    if (password) {
        const hash = await bcrypt.hash(password, 10);
        updateData.password = hash;
    }

    // Handle email update conflict
    if (email && email !== employerExists.email) {
        const emailExists = await Employer.findByEmail(email);
        if (emailExists) {
            return res.status(409).json({ msg: 'Email already in use' });
        }
        updateData.email = email;
    }

    // Check if there's actually data to update
    if (Object.keys(updateData).length === 0) {
        if (email !== undefined && email === employerExists.email) {
            return res.status(200).json({ msg: 'Email unchanged' });
        }
        return res.status(400).json({ msg: 'No valid fields provided for update' });
    }

    // Update
    try {
        const isUpdated = await Employer.update(id, updateData);

        if (isUpdated) {
            const updatedEmployer = await Employer.findById(id);
            return res.status(200).json({
                success: true,
                employer: {
                    id: updatedEmployer.id,
                    name: updatedEmployer.name,
                    email: updatedEmployer.email
                }
            });
        } else {
            return res.status(400).json({ msg: 'Employer update failed' });
        }
    } catch (error) {
        return res.status(500).json({ error: `Error updating employer: ${error.message}` });
    }
});

// @desc    Delete employer
// @route   DELETE /api/employer/:id
// @access Private
const deleteEmployer = asyncHandler(async (req, res) => {
    const isDeleted = await Employer.delete(req.params.id);
    if (isDeleted) {
        res.status(200).json({ msg: 'Employer deleted' });
    } else {
        res.status(404).json({ msg: 'Employer not found' });
    }
});

module.exports = {
    registerEmployer,
    getEmployers,
    getEmployerSelf,
    getEmployerById,
    updateEmployer,
    deleteEmployer
};