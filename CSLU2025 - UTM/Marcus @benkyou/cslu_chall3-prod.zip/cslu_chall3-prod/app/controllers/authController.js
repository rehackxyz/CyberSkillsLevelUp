const asyncHandler = require('express-async-handler');
const bcrypt = require('bcryptjs');
const { validationResult } = require('express-validator');
const Student = require('../models/Student');
const { generateToken } = require('../utils/token');
const Employer = require('../models/Employer');

// @desc    Authenticate student & get token
// @route   POST /api/student/login
// @access  Public
const loginStudent = asyncHandler(async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    const { email, password } = req.body;
    const student = await Student.findByEmail(email);
    if (!student) {
        return res.status(401).json({ msg: 'Invalid credentials entered' });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, student.password);
    if (!isMatch) {
        return res.status(401).json({ msg: 'Invalid credentials entered' });
    }

    // Generate JWT
    const payload = {
        id: student.id,
        email: student.email,
        role: 'student'
    };
    const token = generateToken(payload);
    res.status(200).json({ msg: 'Login success', token: token});
});

// @desc    Authenticate employer & get token
// @route   POST /api/employer/login
// @access  Public
const loginEmployer = asyncHandler(async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { email, password } = req.body;
    const employer = await Employer.findByEmail(email);

    if (!employer || !(await bcrypt.compare(password, employer.password))) {
        return res.status(401).json({ msg: 'Invalid credentials' });
    }

    // Check if account is activated
    if (!employer.is_activated) {
        return res.status(403).json({ 
            msg: 'Account is not activated. Please contact administrator for activation.'
        });
    }

    const payload = {
        id: employer.id,
        email: employer.email,
        role: 'employer'
    };
    const token = generateToken(payload);
    res.status(200).json({ msg: 'Login success', token: token});
});

// @desc    Reset employer account with recovery code
// @route   POST /api/employer/reset-account
// @access  Public
const resetEmployerAccount = asyncHandler(async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { email, recoveryCode } = req.body;
    const success = await Employer.reset(email, recoveryCode);

    if (success) {
        return res.status(200).json({ msg: "We've sent a recovery link to your email. Check your inbox to continue resetting your account."})
    }

    return res.status(400).json({ msg: 'Invalid email or recovery code' });
});

// @desc    Generate OTP for employer to share with staff
// @route   POST /api/employer/generate-otp
// @access  Private
const generateEmployerOTP = asyncHandler(async (req, res) => {
    const employerId = req.user.id;
    
    try {
        const employer = await Employer.findById(employerId);
        
        if (!employer) {
            return res.status(404).json({ msg: 'Employer not found' });
        }

        const otp = await Employer.generateOTP(employerId);
        
        const encodedEmail = Buffer.from(employer.email).toString('base64');
        const shareLink = `${req.protocol}://${req.get('host')}/employer/login/otp/${encodedEmail}/${otp}`;
        
        res.status(200).json({
            msg: 'Your OTP expires in 5 minutes',
            link: shareLink
        });
    } catch (error) {
        console.error('OTP Generation Error:', error);
        res.status(500).json({ msg: 'Error generating OTP' });
    }
});

// @desc    Authenticate employer with OTP
// @route   POST /api/employer/login/otp/:encodedEmail/:otp
// @access  Public
const loginWithOTP = asyncHandler(async (req, res) => {
    const { encodedEmail, otp } = req.params;
    
    try {
        const email = Buffer.from(encodedEmail, 'base64').toString();
        const employer = await Employer.verifyOTP(otp, email);

        if (!employer) {
            return res.status(401).json({ msg: 'Invalid or expired OTP' });
        }

        const payload = {
            id: employer.id,
            email: employer.email,
            role: 'employer'
        };
        
        const token = generateToken(payload);
        res.status(200).json({ 
            msg: 'Login success',
            token 
        });

    } catch (error) {
        res.status(400).json({ msg: 'Invalid login parameters' });
    }
});

module.exports = {
    loginStudent,
    loginEmployer,
    resetEmployerAccount,
    generateEmployerOTP,
    loginWithOTP
};