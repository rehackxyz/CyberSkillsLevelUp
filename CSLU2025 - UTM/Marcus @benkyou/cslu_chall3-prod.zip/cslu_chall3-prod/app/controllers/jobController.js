const asyncHandler = require('express-async-handler');
const Job = require('../models/Job');
const { validationResult } = require('express-validator');

// @desc    Create a new job
// @route   POST /api/jobs
// @access  Private
const createJob = asyncHandler(async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { title, description } = req.body;
    // In hindsight my code is kinda jank 💀
    const employer_id = req.user.id;

    const jobId = await Job.create(title, description, employer_id);
    const job = await Job.findById(jobId);

    res.status(201).json({
        msg: 'Job created successfully',
        job: {
            id: job.id,
            title: job.title,
            description: job.description,
            employer_id: job.employer_id
        }
    });
});

// @desc    Get all jobs
// @route   GET /api/jobs
// @access  Public
const getJobs = asyncHandler(async (req, res) => {
    const { employer_id } = req.query;
    
    if (employer_id) {
        const jobs = await Job.findByEmployerId(employer_id);
        return res.status(200).json(jobs);
    }
    
    const jobs = await Job.findAll();
    res.status(200).json(jobs);
});

// @desc    Get job by ID
// @route   GET /api/jobs/:id
// @access  Public
const getJobById = asyncHandler(async (req, res) => {
    const job = await Job.findById(req.params.id);
    if (!job) {
        return res.status(404).json({ msg: 'Job not found' });
    }
    res.status(200).json(job);
});

// @desc    Get jobs by employer ID
// @route   GET /api/jobs/employer/:id
// @access  Public
const getJobsByEmployer = asyncHandler(async (req, res) => {
    const jobs = await Job.findByEmployerId(req.params.id);
    res.status(200).json(jobs);
});

// @desc    Update job
// @route   PUT /api/jobs/:id
// @access  Private
const updateJob = asyncHandler(async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { title, description } = req.body;
    const jobId = req.params.id;

    const job = await Job.findById(jobId);
    if (!job) {
        return res.status(404).json({ msg: 'Job not found' });
    }

    // Verify employer owns this job
    if (job.employer_id !== req.user.id) {
        return res.status(403).json({ msg: 'Not authorized to update this job' });
    }

    const updateData = {};
    if (title) updateData.title = title;
    if (description) updateData.description = description;

    if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ msg: 'No valid fields provided for update' });
    }

    const isUpdated = await Job.update(jobId, updateData);
    if (isUpdated) {
        const updatedJob = await Job.findById(jobId);
        res.status(200).json({
            success: true,
            job: updatedJob
        });
    } else {
        res.status(400).json({ msg: 'Job update failed' });
    }
});

// @desc    Delete job
// @route   DELETE /api/jobs/:id
// @access  Private
const deleteJob = asyncHandler(async (req, res) => {
    const job = await Job.findById(req.params.id);
    if (!job) {
        return res.status(404).json({ msg: 'Job not found' });
    }

    // Verify employer owns this job
    if (job.employer_id !== req.user.id) {
        return res.status(403).json({ msg: 'Not authorized to delete this job' });
    }

    const isDeleted = await Job.delete(req.params.id);
    if (isDeleted) {
        res.status(200).json({ msg: 'Job deleted' });
    } else {
        res.status(400).json({ msg: 'Job deletion failed' });
    }
});

module.exports = {
    createJob,
    getJobs,
    getJobById,
    getJobsByEmployer,
    updateJob,
    deleteJob
};