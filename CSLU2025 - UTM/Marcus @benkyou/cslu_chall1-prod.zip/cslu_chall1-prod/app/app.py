from flask import Flask, jsonify, request, render_template, redirect, url_for, session
from werkzeug.utils import secure_filename
import bcrypt
import base64
import hashlib
import os
import uuid
from db import get_db_connection

app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'this_key_is_for_testing')
FLAG = os.getenv('FLAG', 'cslu{fakeflag}')

DOCUMENT_FOLDER = os.path.join('static', 'documents')
ALLOWED_EXTENSIONS = {'pdf'}
app.config['UPLOAD_FOLDER'] = DOCUMENT_FOLDER
os.makedirs(DOCUMENT_FOLDER, exist_ok=True)

def allowed_filetype(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', role=session.get('user_role'))

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('profile.html', role=session.get('user_role'))

@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    data = request.get_json()
    email, password = data.get("email"), data.get("password")

    if not email or not password:
        return jsonify({"error": "Missing required fields"}), 400

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE email=%s", (email,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()

    if not user:
        return jsonify({"error": "Invalid email or password"}), 401

    hashed_input = base64.b64encode(hashlib.sha256(password.encode()).digest())
    if not bcrypt.checkpw(hashed_input, user["password"].encode()):
        return jsonify({'error': 'Invalid email or password'}), 401

    session.update({'user_id': user['id'], 'user_name': user['email'], 'user_role': user['role']})
    return jsonify({'message': 'Login successful'}), 200

@app.route('/register', methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html")

    data = request.get_json()
    email, name, password = data.get('email'), data.get('name'), data.get('password')

    if not email or not name or not password:
        return jsonify({"error": "Missing required fields"}), 400

    hashed_password = bcrypt.hashpw(
        base64.b64encode(hashlib.sha256(password.encode()).digest()),
        bcrypt.gensalt()
    )

    conn = get_db_connection()
    if not conn:
        return jsonify({'error': 'Database connection failed'}), 500

    try:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (name, email, password, role) VALUES (%s, %s, %s, 'student')", (name, email, hashed_password))
        conn.commit()
    except conn.IntegrityError:
        return jsonify({'error': 'User with this email already exists'}), 409
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        conn.close()

    return jsonify({"message": "User registered successfully."}), 200

@app.route('/user/<int:id>')
def get_user(id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT id, name, email, company, job_title, job_description, document_url, role FROM users WHERE id = %s', (id,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()

    if user:
        return jsonify(user)
    return jsonify({'error': 'User not found'}), 404

@app.route('/user/<int:id>/edit', methods=['POST'])
def edit_user(id):
    if session.get('user_id') != id:
        return jsonify({'error': 'Unauthorized'}), 403

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT document_url FROM users WHERE id = %s", (id,))
    user = cursor.fetchone()
    if not user:
        cursor.close()
        conn.close()
        return jsonify({'error': 'User not found'}), 404

    name = request.form.get('name')
    company = request.form.get('company')
    job_title = request.form.get('job_title')
    job_description = request.form.get('job_description')
    file = request.files.get('document')

    document_url = user['document_url']
    if file and allowed_filetype(file.filename):
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4().hex}_{filename}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(file_path)
        document_url = f'static/documents/{unique_filename}'

    cursor.execute('''
        UPDATE users 
        SET name = %s,
            company = %s,
            job_title = %s,
            job_description = %s,
            document_url = %s,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = %s
    ''', (name, company, job_title, job_description, document_url, id))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for('profile'))

@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'GET':
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return render_template('reset_password.html', user={'email': session.get('user_name')})

    data = request.get_json()
    email, new_password = data.get('email'), data.get('password')

    if not email or not new_password:
        return jsonify({'error': 'Missing required fields'}), 400

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
    user = cursor.fetchone()

    if not user:
        cursor.close()
        conn.close()
        return jsonify({'error': 'User not found'}), 404

    hashed_password = bcrypt.hashpw(
        base64.b64encode(hashlib.sha256(new_password.encode()).digest()),
        bcrypt.gensalt()
    )

    try:
        cursor.execute('UPDATE users SET password = %s WHERE email = %s', (hashed_password, email))
        conn.commit()
        return jsonify({'message': 'Password updated successfully'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/admin')
def admin():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('admin.html', flag=FLAG if session.get('user_role') == 'admin' else None)

if __name__ == '__main__':
    app.run()
