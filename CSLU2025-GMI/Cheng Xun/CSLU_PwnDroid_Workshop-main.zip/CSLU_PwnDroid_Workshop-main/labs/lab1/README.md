# Lab 1 - Method Hooking for Flag

## Goal
Hook a method and modify its return value to a specific value that returns the flag.

## Instructions
Identify the target method and use Frida to change its return to the required value.

## Flag Format
`cslu{...}`
