# Lab 2 - Cross-Class Method Hooking

## Goal
Hook a method from another class and modify its return value to trigger the flag logic.

## Instructions
Use Frida to locate the method in a different class and override its behavior.

## Flag Format
`cslu{...}`
