# Lab 4 - Static Variable Manipulation

## Goal
Hook and modify a static variable to a specific value to get the flag.

## Instructions
Find the static variable and change it to the expected value using Frida.

## Flag Format
`cslu{...}`

## Easter Egg
There's another way to solve this challenge, just like we've learned before. What is it?
