# Lab 5 - Instantiate Unused Class

## Goal
Learn how to instantiate and interact with an unused class to get the flag.

## Instructions
Use Frida to create an instance of an otherwise unused class and access its method to retrieve the flag.

## Flag Format
`cslu{...}`
