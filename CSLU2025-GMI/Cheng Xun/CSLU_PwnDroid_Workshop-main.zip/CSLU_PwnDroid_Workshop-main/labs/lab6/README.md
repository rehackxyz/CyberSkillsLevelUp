# Lab 6 - Method Call with Parameters

## Goal
Instantiate and invoke a method from an unused class with specific parameters to get the flag.

## Instructions
Use Frida to find the correct method and call it with the expected arguments.

## Flag Format
`cslu{...}`
