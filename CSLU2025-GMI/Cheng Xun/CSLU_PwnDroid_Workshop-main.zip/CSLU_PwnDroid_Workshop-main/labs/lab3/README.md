# Lab 3 - Static Variable Hooking

## Goal
Introduction to hooking and modifying static variables from another class.

## Instructions
Use Frida to identify and change the value of a static variable that influences app logic.
