Java.perform(function() {
  var externalclass = Java.use("definitely.notvulnerable.fridalab3.ExternalClass");
  externalclass.number.value = 5;
})