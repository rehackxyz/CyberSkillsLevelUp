# Lab 0 - Intro to Method Hooking

## Goal
Learn how to hook a method using Frida and modify its return value.

## Instructions
Use Frida to intercept and change the return value of a method to understand the basics of dynamic instrumentation.